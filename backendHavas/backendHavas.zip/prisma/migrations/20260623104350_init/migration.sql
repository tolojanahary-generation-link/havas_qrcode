/*
  Warnings:

  - You are about to drop the column `collaboratoreId` on the `User` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "Folder" DROP CONSTRAINT "Folder_collaboratorId_fkey";

-- DropForeignKey
ALTER TABLE "User" DROP CONSTRAINT "User_collaboratoreId_fkey";

-- AlterTable
ALTER TABLE "Folder" ALTER COLUMN "collaboratorId" DROP NOT NULL;

-- AlterTable
ALTER TABLE "User" DROP COLUMN "collaboratoreId",
ADD COLUMN     "collaboratorId" INTEGER,
ALTER COLUMN "phone" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "User" ADD CONSTRAINT "User_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Folder" ADD CONSTRAINT "Folder_collaboratorId_fkey" FOREIGN KEY ("collaboratorId") REFERENCES "Collaborator"("id") ON DELETE SET NULL ON UPDATE CASCADE;
